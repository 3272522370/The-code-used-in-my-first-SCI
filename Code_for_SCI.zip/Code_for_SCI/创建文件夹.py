import os
for i in range(2003,2024):
    os.mkdir('F:\\NPP（二季晚稻）\\'+str(i))